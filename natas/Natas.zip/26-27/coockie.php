<?php

$drawing=unserialize(base64_decode("YToxOntpOjA7YTo0OntzOjI6IngxIjtzOjE6IjEiO3M6MjoieTEiO3M6MToiMSI7czoyOiJ4MiI7czoxOiIxIjtzOjI6InkyIjtzOjE6IjEiO319="));
print_r($drawing);

?>
